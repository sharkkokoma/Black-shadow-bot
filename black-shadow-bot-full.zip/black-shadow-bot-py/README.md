# 🖤 BLACK SHADOW Discord Bot (Python) ⚔️

Bot ពេញលេញ — Welcome system + Moderation + Utility + Fun + **Web3.0 Rules** — ទាំងអស់ជា **Slash Commands**។ រួមមាន keep-alive server សម្រាប់ដំណើរការ 24/7។

## 📁 រចនាសម្ព័ន្ធ Project

```
black-shadow-bot-py/
├── main.py              # ចាប់ផ្តើម bot + sync slash commands
├── config.py             # កំណត់ token, channel IDs, អត្ថបទ, ពណ៌
├── keep_alive.py          # Flask server សម្រាប់ 24/7 uptime
├── welcome_card.py        # បង្កើតរូបភាព welcome card
├── rules_banner.py        # បង្កើត banner Web3.0 សម្រាប់ /rules
├── requirements.txt
├── .env.example
├── .replit
└── cogs/
    ├── welcome.py         # Welcome/Leave/Auto-role events
    ├── moderation.py      # /kick /ban /mute /warn ។ល។
    ├── utility.py         # /userinfo /serverinfo /avatar ។ល។
    ├── fun.py             # /coinflip /8ball /rps /poll ។ល។
    └── rules.py            # /rules — Web3.0 styled
```

---

## 📜 បញ្ជី Slash Commands ទាំងអស់

### ⚔️ Moderation (ត្រូវការ permission)
| Command | ការពិពណ៌នា |
|---|---|
| `/kick` | បណ្តេញសមាជិកចេញ |
| `/ban` | Ban សមាជិក (អាចលុបសារចាស់ជាមួយ) |
| `/unban` | Unban តាម User ID |
| `/mute` | Timeout សមាជិកមួយរយៈពេល |
| `/unmute` | ដក Timeout |
| `/warn` | ព្រមានសមាជិក |
| `/clear` | លុបសារច្រើនក្នុងម្តង (1-100) |
| `/lock` | Lock channel |
| `/unlock` | Unlock channel |
| `/slowmode` | កំណត់ slowmode |
| `/nickname` | ប្តូរ nickname សមាជិក |

### 🛠️ Utility
| Command | ការពិពណ៌នា |
|---|---|
| `/ping` | មើល latency |
| `/userinfo` | ព័ត៌មានលម្អិតសមាជិក |
| `/serverinfo` | ព័ត៌មាន server |
| `/avatar` | មើល avatar ពេញ |
| `/banner` | មើល banner សមាជិក |
| `/roleinfo` | ព័ត៌មាន role |
| `/membercount` | ចំនួនសមាជិក (មនុស្ស/bot) |
| `/botinfo` | ព័ត៌មាន bot + uptime |
| `/invite` | Invite link របស់ bot |

### 🎉 Fun
| Command | ការពិពណ៌នា |
|---|---|
| `/coinflip` | បោះកាក់ |
| `/dice` | បោះឡុកឡាក់ |
| `/8ball` | សួរ Magic 8-Ball |
| `/rps` | ជល់ដំបង-ក្រដាស-កន្ត្រៃ vs bot |
| `/poll` | បង្កើត poll 👍👎 |
| `/say` | ឱ្យ bot និយាយ (Admin) |
| `/embed` | បង្កើត embed ផ្ទាល់ខ្លួន (Admin) |

### ⛓️ Rules — Web3.0 Style
| Command | ការពិពណ៌នា |
|---|---|
| `/rules` | ប្រកាស Server Rules រចនាប័ទ្ម Web3.0 (neon banner + protocol-style embed) — ត្រូវការ permission Manage Server |

**Welcome System** (ស្វ័យប្រវត្តិ — មិនមែន command): welcome card image, DM welcome, auto-role, leave message, member count channel

---

## 📋 ជំហានទី ១: បង្កើត Bot នៅ Discord Developer Portal

1. ចូល https://discord.com/developers/applications
2. **New Application** → ដាក់ឈ្មោះ `BLACK SHADOW BOT`
3. **Bot** → **Add Bot**
4. ក្រោម **Privileged Gateway Intents** បើក:
   - ✅ SERVER MEMBERS INTENT
   - ✅ MESSAGE CONTENT INTENT
5. **Reset Token** → Copy (ដាក់ក្នុង `.env`)
6. **OAuth2 → URL Generator**:
   - Scopes: `bot`, `applications.commands` (ចាំបាច់សម្រាប់ slash commands!)
   - Permissions: `Administrator` (ងាយបំផុត) ឬជ្រើសដាច់ដោយឡែក: Manage Roles, Kick, Ban, Timeout, Manage Messages, Manage Channels, Manage Nicknames
   - Copy URL → Authorize ចូល server

---

## 📋 ជំហានទី ២: យក IDs

Developer Mode (Settings → Advanced) → Right-click → Copy ID:
- Guild ID (ឈ្មោះ server)
- Client ID (Developer Portal → General Information)
- Welcome/Leave/Member Count channel IDs
- Mod-log channel ID (មិនចាំបាច់)
- Auto-role ID

---

## 📋 ជំហានទី ៣: Setup លើ Replit

1. https://replit.com → **Create Repl** → **Python**
2. Upload files ទាំងអស់ (រក្សា folder structure `cogs/` ដដែល)
3. **Tools → Secrets**:
   ```
   DISCORD_TOKEN, GUILD_ID, CLIENT_ID
   WELCOME_CHANNEL_ID, LEAVE_CHANNEL_ID, MEMBER_COUNT_CHANNEL_ID
   MOD_LOG_CHANNEL_ID, AUTO_ROLE_ID
   ```
4. Shell: `pip install -r requirements.txt`
5. ចុច **Run** ▶️

**Slash commands លេចភ្លាមៗ** ព្រោះ `GUILD_ID` ត្រូវបានកំណត់ (guild-specific sync = instant)។ បើមិនកំណត់ `GUILD_ID`, commands sync ជា global ដែលចំណាយពេលដល់ ១ ម៉ោងដើម្បីលេចគ្រប់ server។

**24/7:** ចង្អុល UptimeRobot ទៅ Replit URL, ឬប្រើ Replit Deployments (Reserved VM) សម្រាប់ស្ថេរភាពល្អជាង។

---

## 🧪 Local Testing

```bash
pip install -r requirements.txt
cp .env.example .env
# កែ .env
python3 main.py
```

---

## ⚙️ កែសម្រួល

- **Welcome/Leave/ពណ៌**: `config.py`
- **Rules content**: `cogs/rules.py` → `DEFAULT_RULES` list
- **Rules banner design**: `rules_banner.py`
- **Welcome card design**: `welcome_card.py`
- **បន្ថែម command ថ្មី**: បន្ថែម method ក្នុង cog ដែលពាក់ព័ន្ធ (moderation/utility/fun) ដោយប្រើ `@app_commands.command(...)`

---

## ❓ Troubleshooting

| បញ្ហា | ដំណោះស្រាយ |
|---|---|
| Slash commands មិនលេច | ត្រូវប្រាកដថា invite URL មាន scope `applications.commands` + ត្រូវរង់ចាំ ១ម៉ោង បើគ្មាន `GUILD_ID` |
| `Missing Access` error | Bot role ត្រូវនៅលើ role គោលដៅ (សម្រាប់ kick/ban/mute) |
| Auto-role មិនដំណើរការ | បើក `SERVER MEMBERS INTENT` ក្នុង Developer Portal |
| `/rules` បរាជ័យ | User ត្រូវការ permission **Manage Server** |
| Font មិនស្អាតលើ banner | Replit/Linux មាន DejaVu Sans រួចស្រាប់ជាធម្មតា |
| ModuleNotFoundError | `pip install -r requirements.txt` ម្តងទៀត |
